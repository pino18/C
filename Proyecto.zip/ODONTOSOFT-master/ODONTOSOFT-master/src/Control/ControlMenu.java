package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import BaseDatos.Data;
import View.InterfazVista;
import View.PanelAddOpt;
import View.PanelCancelarCita;
import View.PanelConsultarHistoria;
import View.PanelInicio;
import View.PanelLogin;
import View.PanelModificarCita;
import View.PanelModificarHistoria;
import View.PanelPagarRecibo;
import View.PanelRegistrarAdminEmple;
import View.PanelRemoveOpt;
import View.PanelRenunciar;
import View.PanelSeeOpt;
import View.PanelSolicitarCita;
import View.PanelUsuario;
import View.PanelValoracion;
import View.VentanaPP;
import View.FieldPanel.FieldPanel;
import gestorAplicacion.documents.HistoriaClinica;
import gestorAplicacion.users.Acompaniante;
import gestorAplicacion.users.AdminUser;
import gestorAplicacion.users.Empleado;
import gestorAplicacion.users.Paciente;
import gestorAplicacion.users.User;

public class ControlMenu implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {

//Es oyente de todos los items para el men� de cada usuario
		String option = e.getActionCommand();

//Opcion para un boton que permite volver al PanelLogin (O sea al inicio sin cerrar sesi�n)
		if (option.equals(InterfazVista.CANCELAR)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelLogin());
			VentanaPP.ventana.pack();

//Opciones para cuando el usuario desea ver o cambiar su informaci�n
		} else if (option.equals(InterfazVista.USUARIO) || option.equals(InterfazVista.MODIFICARUSER)) {

			// Campos que van a tener todos los usuarios
			ArrayList<String> labels = new ArrayList<String>();
			labels.add("Tipo de usuario");
			labels.add("Identificaci�n");
			labels.add("Nombre completo");
			labels.add("Edad");
			labels.add("Telefono");
			labels.add("Sexo");
			labels.add("Nombre de usuario");
			labels.add("E-mail");
			labels.add("Contrase�a");

			// Valores que van a tener todos los usuarios
			ArrayList<String> valdef = new ArrayList<String>();

			valdef.add(User.currentUser.getIdentificacion());
			valdef.add(User.currentUser.getFullname());
			valdef.add(User.currentUser.getEdad());
			valdef.add(User.currentUser.getTelefono());
			valdef.add(User.currentUser.getSexo());
			valdef.add(User.currentUser.getUsername());
			valdef.add(User.currentUser.getEmail());
			valdef.add(User.currentUser.getPassword());

			// Array que permite o no modificar los campos
			ArrayList<Boolean> mod = new ArrayList<Boolean>();

//Panel para cuando el usuario desee visualizar su informaci�n b�sica

			if (option.equals(InterfazVista.USUARIO)) {
				if (User.currentUser instanceof Paciente) {
					valdef.add(0, "Paciente");
					for (String val : labels) {
						mod.add(false);
					}
				} else if (User.currentUser instanceof Acompaniante) {
					valdef.add(0, "Acompa�ante");
					labels.add("Usuario al que acompa�a");
					labels.add("Parentezco");
					valdef.add(((Acompaniante) User.currentUser).getPaciente().getUsername());
					valdef.add(((Acompaniante) User.currentUser).getParentezco());
					for (String val : labels) {
						mod.add(false);
					}
				} else if (User.currentUser instanceof Empleado) {
					valdef.add(0, "Empleado");
					labels.add("Contrato");
					labels.add("Cargo");
					labels.add("Sueldo");
					labels.add("Horario");
					valdef.add(((Empleado) User.currentUser).getContrato());
					valdef.add(((Empleado) User.currentUser).getCargo());
					valdef.add(Integer.toString(((Empleado) User.currentUser).getSueldo()));
					valdef.add(((Empleado) User.currentUser).getHorario());
					for (String val : labels) {
						mod.add(false);
					}
				} else if (User.currentUser instanceof AdminUser) {
					valdef.add(0, "Admin");
					for (String val : labels) {
						mod.add(false);
					}
				}

				VentanaPP.contenedor.removeAll();
				VentanaPP.contenedor.add(new PanelUsuario(true, new FieldPanel("Campo", labels, "Valor", valdef, mod)));
				VentanaPP.ventana.pack();

//Panel para cuando el usuario desee cambiar su informacion b�sica

			} else if (option.equals(InterfazVista.MODIFICARUSER)) {

				// valores a cambiar por default
				mod.add(false);
				mod.add(false);
				mod.add(true);
				mod.add(true);
				mod.add(true);
				mod.add(true);
				mod.add(false);
				mod.add(true);
				mod.add(true);

				if (User.currentUser instanceof Paciente) {
					valdef.add(0, "Paciente");
				} else if (User.currentUser instanceof Acompaniante) {
					valdef.add(0, "Acompa�ante");
					labels.add("Usuario al que acompa�a");
					labels.add("Parentezco");
					valdef.add(((Acompaniante) User.currentUser).getPaciente().getUsername());
					valdef.add(((Acompaniante) User.currentUser).getParentezco());
					mod.add(false);
					mod.add(false);
				} else if (User.currentUser instanceof Empleado) {
					valdef.add(0, "Empleado");
					labels.add("Contrato");
					labels.add("Cargo");
					labels.add("Sueldo");
					labels.add("Horario");
					valdef.add(((Empleado) User.currentUser).getContrato());
					valdef.add(((Empleado) User.currentUser).getCargo());
					valdef.add(Integer.toString(((Empleado) User.currentUser).getSueldo()));
					valdef.add(((Empleado) User.currentUser).getHorario());
					mod.add(false);
					mod.add(false);
					mod.add(false);
					mod.add(false);
				} else if (User.currentUser instanceof AdminUser) {
					valdef.add(0, "Admin");
				}

				VentanaPP.contenedor.removeAll();
				VentanaPP.contenedor
						.add(new PanelUsuario(false, new FieldPanel("Campo", labels, "Valor", valdef, mod)));
				VentanaPP.ventana.pack();
			}

// Opcion de Salir en el men� que permite cerrar sesi�n y guardar el proceso realizado

		} else if (option.equals(InterfazVista.SALIR)) {
			User.currentUser = null;
			Data.saveData();
			ControlOption.con1 = 0;
			ControlOption.con2 = 0;
			VentanaPP.contenedor.removeAll();
			VentanaPP.menuBarra.removeAll();
			VentanaPP.contenedor.add(new PanelInicio());
			VentanaPP.ventana.pack();

// Opci�n Pagar recibo en el Men�

		} else if (option.equals(InterfazVista.PAGARRECIBO)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelPagarRecibo());
			VentanaPP.ventana.pack();

//Opci�n Ver historia en el Men�

		} else if (option.equals(InterfazVista.HISTORIA)) {
			Paciente U = (Paciente) User.currentUser;
			HistoriaClinica HC = Data.historias.get(U.getIdentificacion());
			ArrayList<String> labels = new ArrayList<String>();
			labels.add("Identificacion");
			labels.add("Nombre del Paciente");
			labels.add("Numero de citas realizadas");
			labels.add("Informacion a tener en cuenta");
			ArrayList<String> value = new ArrayList<String>();
			value.add(U.getIdentificacion());
			value.add(U.getFullname());
			value.add(Integer.toString(HC.getNroCitasRealizadas()));
			value.add(HC.getInformacion());
			ArrayList<Boolean> HAB = new ArrayList<Boolean>();
			HAB.add(false);
			HAB.add(false);
			HAB.add(false);
			HAB.add(false);
			FieldPanel FP = new FieldPanel("Campo", labels, "Valor", value, HAB);
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelConsultarHistoria(FP));
			VentanaPP.ventana.pack();
		}
//Opci�n para agregar un nuevo administrador que est� s�lo en el men�
// de un usuario de tipo AdminUser

		else if (option.equals(InterfazVista.MODIFICARHISTORIA)) {
			
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelModificarHistoria(true, null));
			VentanaPP.ventana.pack();
		}

		else if (option.equals(InterfazVista.NEWADMIN)) {
			ArrayList<String> labels = new ArrayList<String>();

			labels.add("Identificaci�n");
			labels.add("Nombre completo");
			labels.add("Edad");
			labels.add("Telefono");
			labels.add("Sexo");
			labels.add("Nombre de usuario");
			labels.add("E-mail");
			labels.add("Contrase�a");

			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelRegistrarAdminEmple(PanelRegistrarAdminEmple.ADMIN,
					new FieldPanel("Campo", labels, "Valor", null, null)));
			VentanaPP.ventana.pack();

//Opci�n para agregar un nuevo empleado que est� s�lo en el men�
// de un usuario de tipo AdminUser

		} else if (option.equals(InterfazVista.NEWEMPLEADO)) {
			ArrayList<String> labels = new ArrayList<String>();

			labels.add("Identificaci�n");
			labels.add("Nombre completo");
			labels.add("Edad");
			labels.add("Telefono");
			labels.add("Sexo");
			labels.add("Nombre de usuario");
			labels.add("E-mail");
			labels.add("Contrase�a");
			labels.add("Contrato");
			labels.add("Cargo");
			labels.add("Sueldo");
			labels.add("Horario");

			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelRegistrarAdminEmple(PanelRegistrarAdminEmple.EMPLEADO,
					new FieldPanel("Campo", labels, "Valor", null, null)));
			VentanaPP.ventana.pack();
		}

//Opcion del men� para ver las opciones del usuario
//opcion s�lo visible para admin

		else if (option.equals(InterfazVista.VEROPTION)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelSeeOpt());
			VentanaPP.ventana.pack();
		}

//Opcion del men� para a�adir opciones al usuario
//opcion s�lo visible para admin

		else if (option.equals(InterfazVista.AGREGAROPTION)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelAddOpt());
			VentanaPP.ventana.pack();
		}
// Opcion del men� para eliminar opciones al usuario
// opcion s�lo visible para admin

		else if (option.equals(InterfazVista.ELIMINAROPTION)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelRemoveOpt());
			VentanaPP.ventana.pack();
		}

		else if (option.equals(InterfazVista.MODIFICARCITA)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelModificarCita());
			VentanaPP.ventana.pack();
		}

		else if (option.equals(InterfazVista.VALORACION)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelValoracion());
			VentanaPP.ventana.pack();
		}
		else if (option.equals(InterfazVista.CANCELARCITA)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelCancelarCita());
			VentanaPP.ventana.pack();
		}
		else if (option.equals(InterfazVista.RENUNCIA)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelRenunciar());
			VentanaPP.ventana.pack();
		}
		else if (option.equals(InterfazVista.SOLICITARCITA)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelSolicitarCita());
			VentanaPP.ventana.pack();
		}
	}
}
