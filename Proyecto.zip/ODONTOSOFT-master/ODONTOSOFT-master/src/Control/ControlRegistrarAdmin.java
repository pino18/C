package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import View.PanelInicio;
import View.PanelLogin;
import View.PanelRegistrarAdminEmple;
import View.VentanaPP;
import gestorAplicacion.users.AdminUser;
import gestorAplicacion.users.Empleado;
import gestorAplicacion.users.User;

public class ControlRegistrarAdmin implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		ArrayList<String> values = PanelRegistrarAdminEmple.Field.getValues();
		if (!values.contains("")) {
			if (User.getUserByUsername(values.get(5))==null) {
				try {
					if (PanelRegistrarAdminEmple.kind.equals(PanelRegistrarAdminEmple.ADMIN)) {
						AdminUser.newAdminUser(values.get(0),values.get(1),values.get(2),values.get(3),values.get(4),values.get(5),values.get(6),values.get(7));
						JOptionPane.showMessageDialog(null, "El usuario -Admin- se ha creado con exito", "Bienvenido a ODONTOSOFT", JOptionPane.INFORMATION_MESSAGE);
						VentanaPP.contenedor.removeAll();
						VentanaPP.contenedor.add(new PanelLogin());
						VentanaPP.ventana.pack();
					}
					else if (PanelRegistrarAdminEmple.kind.equals(PanelRegistrarAdminEmple.EMPLEADO)) {
						//try {
							User.newUser(new Empleado(values.get(8),values.get(9),values.get(10),values.get(11)), values.get(0),values.get(1),values.get(2),values.get(3),values.get(4),values.get(5),values.get(6),values.get(7));
							JOptionPane.showMessageDialog(null, "El usuario -Empleado- se ha creado con exito", "Bienvenido a ODONTOSOFT", JOptionPane.INFORMATION_MESSAGE);
							VentanaPP.contenedor.removeAll();
							VentanaPP.contenedor.add(new PanelLogin());
							VentanaPP.ventana.pack();
					}
				}catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "El campo -Sueldo- s�lo admite n�meros", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese nombre", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
		}
		else {
			JOptionPane.showMessageDialog(null, values, "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

}
