package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

import View.InterfazVista;
import View.PanelRemoveOpt;
import View.PanelLogin;
import View.VentanaPP;
import errorAplication.NotFoundException;
import uiMain.OpcionDeMenu;
import uiMain.operations.RemoveOpt;
import uiMain.operations.SeeOpt;

//Este controlador premite modificar el panel de a�adir opciones al usuario

public class ControlRemoveOpt implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		String USER = PanelRemoveOpt.USER.getText();
		if (e.getActionCommand().equals(InterfazVista.ACEPTAR)) {
			try {
				if (PanelRemoveOpt.SW == 2) {
					/*Aqui se obtienen los valores de los checkbox existentes en
					  panel a�adir opciones a usuario (PanelAddOpt)
					  para poder ir al modelo y cumplir con su funcion*/
					
					ArrayList<JCheckBox> CB = PanelRemoveOpt.CB;
										
					int I;
					for (I = 0; I < CB.size(); I++) {
						JCheckBox AUX =CB.get(I);
							if (AUX.isSelected()) {
								CB.remove(I);
								RemoveOpt.ejecutar(I, USER);
								I--;
						}
					}
					JOptionPane.showMessageDialog(null, "Las opciones han sido eliminadas", "ADICION EXITOSA",
							JOptionPane.INFORMATION_MESSAGE);
					PanelRemoveOpt.SW = 3;
					PanelRemoveOpt.CB.clear();
					VentanaPP.contenedor.removeAll();
					VentanaPP.contenedor.add(new PanelLogin());
					VentanaPP.ventana.pack();
				}
				if (PanelRemoveOpt.SW == 1) {
					if (!USER.equals("")) {
						/*Este if valida que la persona llene 
						el campo nombre de usuario del panel ver opciones*/
						
						/*A continuacion se obtienen dos ArrayList
						 donde estan todas las opciones de menu existentes
						 y las que solo posee el usuario ingresado*/
						
						ArrayList<String> useropt = SeeOpt.ejecutar(USER);
						
						/*la variable SW permite acceder a 
						alguna de las dos opciones de este controlador*/
						PanelRemoveOpt.SW = 2;
						
						VentanaPP.contenedor.removeAll();
						VentanaPP.contenedor.add(new PanelRemoveOpt(useropt));
						VentanaPP.ventana.pack();
					} else {
						/*Arroja una ventana emergente en caso de que la persona
						 no llene el campo nombre de usuario donde da una alerta*/
						JOptionPane.showMessageDialog(null, "El campo nombre de usuario no fue llenado", "Campo vacio",
								JOptionPane.WARNING_MESSAGE);
					}
				}
				if(PanelRemoveOpt.SW == 3) {
					PanelRemoveOpt.SW = 1;
				}

			} catch (NotFoundException EX) {
				/*Este catch se encarga de arrojar una ventana emergente
				  en caso de que el programa arroje un error por haber 
				  ingresado un nombre de usuario que no existe*/
				JOptionPane.showMessageDialog(null, "No existe un usuario " + USER, "Usuario no encontrado",
						JOptionPane.WARNING_MESSAGE);
			}
		}else if(e.getActionCommand().equals(InterfazVista.CANCELAR)) {
			PanelRemoveOpt.SW = 1;
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelLogin());
			VentanaPP.ventana.pack();
		}

	}

}
