package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import BaseDatos.Data;
import View.InterfazVista;
import View.PanelLogin;
import View.PanelModificarHistoria;
import View.VentanaPP;
import View.FieldPanel.FieldPanel;
import gestorAplicacion.documents.HistoriaClinica;
import gestorAplicacion.users.Paciente;
import gestorAplicacion.users.User;

public class ControlModificarHistoria implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		String option = e.getActionCommand();
		if (option.equals(InterfazVista.ACEPTAR)) {
			if (!PanelModificarHistoria.ID.equals("")) {
				HistoriaClinica HC = Data.historias.get(PanelModificarHistoria.ID.getText());
				if (HC != null) {
					ArrayList<String> labels = new ArrayList<String>();
					labels.add("Identificacion");
					labels.add("Nombre del Paciente");
					labels.add("Numero de citas realizadas");
					labels.add("Informacion a tener en cuenta");
					ArrayList<String> value = new ArrayList<String>();
					value.add(HC.getID());
					value.add(HC.getPaciente().getUsername());
					value.add(Integer.toString(HC.getNroCitasRealizadas()));
					value.add(HC.getInformacion());
					ArrayList<Boolean> HAB = new ArrayList<Boolean>();
					HAB.add(false);
					HAB.add(false);
					HAB.add(false);
					HAB.add(true);
					
					VentanaPP.contenedor.removeAll();
					VentanaPP.contenedor.add(new PanelModificarHistoria(false, new FieldPanel("Campo", labels, "Valor", value, HAB)));
					VentanaPP.ventana.pack();
				}
				else {
					JOptionPane.showMessageDialog(null, "Identificaci�n invalida", "ERROR",
							JOptionPane.WARNING_MESSAGE);
				}

			} else {
				JOptionPane.showMessageDialog(null, "El campo identificacion del usuario no fue llenado", "Campo vacio",
						JOptionPane.WARNING_MESSAGE);
			}
		}
		else if (option.equals(InterfazVista.GUARDAR)) {
			ArrayList<String> values = PanelModificarHistoria.Field.getValues();
			if (!values.contains("")) {
				HistoriaClinica HC = Data.historias.get(PanelModificarHistoria.ID.getText());
				HC.setInformacion(values.get(3));
				JOptionPane.showMessageDialog(null, "Guardado exitosamente", "informacion",
						JOptionPane.INFORMATION_MESSAGE);

				VentanaPP.contenedor.removeAll();
				VentanaPP.contenedor.add(new PanelLogin());
				VentanaPP.ventana.pack();
			} else {
				JOptionPane.showMessageDialog(null, "Por favor llene todos los campos", "ERROR",
						JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}

}
