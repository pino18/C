package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import BaseDatos.Data;
import View.PanelLogin;
import View.PanelModificarCita;
import View.PanelRegistrar;
import View.VentanaPP;
import View.FieldPanel.FieldPanel;
import gestorAplicacion.documents.Cita;
import gestorAplicacion.documents.HistoriaClinica;
import gestorAplicacion.documents.Procedimiento;
import gestorAplicacion.documents.Recibo;
import gestorAplicacion.users.Paciente;

public class ControlModificarCita implements ActionListener {
//se lleva a cabo el mismo proceso qeu en operations, cuando era por menu de consola
	@Override
	public void actionPerformed(ActionEvent e) {
		String numcita = PanelModificarCita.numcita.getText();
		Cita C = Data.citasByN.get(numcita);
		if (C == null) {
			JOptionPane.showMessageDialog(null, "Cita no encontrada", "ERROR", JOptionPane.ERROR_MESSAGE);
		} else {
			String Input = PanelModificarCita.procedi.getText();
			if (PanelModificarCita.option.getSelectedItem().equals("No")) {
				JOptionPane.showMessageDialog(null, "Se debe haber realizado la cita para hacer cambios.", "ERROR",
						JOptionPane.ERROR_MESSAGE);
			} else if (PanelModificarCita.option.getSelectedItem().equals("Si")) {
				if (Data.proced.containsKey(Input)) {
					Procedimiento PRO = Data.proced.get(Input);
//se ctualiza la informacion de las citas y posteriormente se mete a la base de datos lo nuevo
					String FH = C.getFecha() + C.getHora();
					C.setEstado("realizada");
					C.setProcedimiento(PRO);
					Paciente P = C.getPaciente();
					HistoriaClinica H = Data.historias.get(P.getIdentificacion());
					H.AddNroCitasRealizadas();
					Data.historias.put(H.getID(), H);
					Data.citas.put(FH, C);
					Data.citasByN.put(numcita, C);
					String IDRecibo;
//se genera el recibo de pago a partir del procedimiento que se hizo en la cita					
					while (true) {
						IDRecibo = Recibo.GenNroRecibo();
						if (IDRecibo != null) {
							break;
						}
					}
					Recibo R = new Recibo(IDRecibo, "pendiente", PRO);
					Data.reci.put(IDRecibo, R);

					JOptionPane.showMessageDialog(null, "La cita se ha Modificado Exitosamente", "Modificar",
							JOptionPane.INFORMATION_MESSAGE);
					VentanaPP.contenedor.removeAll();
					VentanaPP.contenedor.add(new PanelLogin());
					VentanaPP.ventana.pack();
					PanelRegistrar.Field = new FieldPanel();

				} else {
					JOptionPane.showMessageDialog(null, "El procedimiento ingresado es erroneo", "ERROR",
							JOptionPane.ERROR_MESSAGE);
				}
			}

		}
	}

}
