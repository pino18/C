package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import View.InterfazVista;
import View.PanelInicio;
import View.PanelLogin;
import View.PanelRegistrar;
import View.PanelValoracion;
import View.VentanaPP;
import View.FieldPanel.FieldPanel;
import errorAplication.ErrorAplication;
import errorAplication.ExceptionC1;
import errorAplication.InstanceException;
import gestorAplicacion.users.Acompaniante;
import gestorAplicacion.users.AdminUser;
import gestorAplicacion.users.Empleado;
import gestorAplicacion.users.Paciente;
import gestorAplicacion.users.User;

public class ControlOption implements ActionListener {

	static int con1 = 0;
	static int con2 = 0;
	static String instancia;
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
// Permite controlar todas las acciones que acurren con los botones de sistema en el Panel de inicio
		String option = e.getActionCommand();

//Con el bot�n Administrador
		if (option.equals(InterfazVista.INICIARADMIN)) {
			if (con1 == 0) {
				PanelInicio.P6.setVisible(true);
				PanelInicio.P7.setVisible(true);
				PanelInicio.iniciar.setLabel("Administrador Complete y Nuevamente Clic");
				PanelInicio.iniciar2.setLabel(InterfazVista.INICIARUSER);
				PanelInicio.PCHANGE.removeAll();
				PanelInicio.PCHANGE.add(PanelInicio.iniciar);
				PanelInicio.P5.removeAll();
				PanelInicio.P5.add(PanelInicio.iniciar2);
				PanelInicio.P5.add(PanelInicio.registrar);
				con1++;
				con2 = 0;
			} else {
				instancia=InterfazVista.INICIARADMIN;
				this.Login();
			}
		} else if (option.equals(InterfazVista.INICIARUSER)) {
			if (con2 == 0) {
				PanelInicio.P6.setVisible(true);
				PanelInicio.P7.setVisible(true);
				PanelInicio.iniciar2.setLabel("UsuarioCom�n Complete y Nuevamente Clic");
				PanelInicio.iniciar.setLabel(InterfazVista.INICIARADMIN);
				PanelInicio.PCHANGE.removeAll();
				PanelInicio.PCHANGE.add(PanelInicio.iniciar2);
				PanelInicio.P5.removeAll();
				PanelInicio.P5.add(PanelInicio.iniciar);
				PanelInicio.P5.add(PanelInicio.registrar);
				con2++;
				con1 = 0;
			} else {
				instancia=InterfazVista.INICIARUSER;
				this.Login();
			}
		} else if (option.equals(InterfazVista.REGISTRAR)) {
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelRegistrar());
			VentanaPP.ventana.pack();
		} else if (option.equals(InterfazVista.VALORACION)) {

			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelValoracion());
			VentanaPP.ventana.pack();
		} else if (option.equals(InterfazVista.VOLVER)) {
			ControlOption.con1=0;
			ControlOption.con2=0;
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelLogin());
			VentanaPP.ventana.pack();
			PanelRegistrar.Field = new FieldPanel();
		}
	}

	private void Login() {
		try {
			PanelInicio.Campos();
			PanelInicio panel = (PanelInicio) VentanaPP.contenedor.getComponent(0);
			String user = panel.getUser();
			String password = panel.getPassword();
			String login = User.login(user, password);
			this.Instancia(User.currentUser);
			
			JMenu archivo = new JMenu("Archivo");
			JMenuItem usuario = new JMenuItem(InterfazVista.USUARIO);
			usuario.addActionListener(new ControlMenu());
			archivo.add(usuario);

			JMenuItem salir = new JMenuItem(InterfazVista.SALIR);
			salir.addActionListener(new ControlMenu());
			archivo.add(salir);
			JMenu procesos = new JMenu("Procesos y Consultas");
			JMenu ayuda = new JMenu(InterfazVista.AYUDA);
			String[] opt = User.currentUser.getMenu().getOperations();
			for (String num : opt) {
				switch (num) {
				case ("1"):
					JMenuItem opt1 = new JMenuItem(InterfazVista.VEROPTION);
					opt1.addActionListener(new ControlMenu());
					procesos.add(opt1);
					break;
				case ("2"):
					JMenuItem opt2 = new JMenuItem(InterfazVista.AGREGAROPTION);
					opt2.addActionListener(new ControlMenu());
					procesos.add(opt2);
					break;
				case ("3"):
					JMenuItem opt3 = new JMenuItem(InterfazVista.ELIMINAROPTION);
					opt3.addActionListener(new ControlMenu());
					procesos.add(opt3);
					break;
				case ("4"):
					JMenuItem opt4 = new JMenuItem(InterfazVista.NEWADMIN);
					opt4.addActionListener(new ControlMenu());
					procesos.add(opt4);
					break;
				case ("5"):
					JMenuItem opt5 = new JMenuItem(InterfazVista.NEWEMPLEADO);
					opt5.addActionListener(new ControlMenu());
					procesos.add(opt5);
					break;
				case ("6"):
					JMenuItem opt6 = new JMenuItem(InterfazVista.SOLICITARCITA);
					opt6.addActionListener(new ControlMenu());
					procesos.add(opt6);
					break;
				case ("7"):
					JMenuItem opt7 = new JMenuItem(InterfazVista.CANCELARCITA);
					opt7.addActionListener(new ControlMenu());
					procesos.add(opt7);
					break;
				case ("8"):
					JMenuItem opt8 = new JMenuItem(InterfazVista.PAGARRECIBO);
					opt8.addActionListener(new ControlMenu());
					procesos.add(opt8);
					break;
				case ("9"):
					JMenuItem opt9 = new JMenuItem(InterfazVista.ACTIVOSACTUALES);
					opt9.addActionListener(new ControlActivosActuales());
					procesos.add(opt9);
					break;
				case ("10"):
					JMenuItem opt10 = new JMenuItem(InterfazVista.HISTORIA);
					opt10.addActionListener(new ControlMenu());
					procesos.add(opt10);
					break;
				case ("11"):
					JMenuItem opt11 = new JMenuItem(InterfazVista.RENUNCIA);
					opt11.addActionListener(new ControlMenu());
					procesos.add(opt11);
					break;
				case ("13"):
					JMenuItem opt13 = new JMenuItem(InterfazVista.MODIFICARHISTORIA);
					opt13.addActionListener(new ControlMenu());
					procesos.add(opt13);
					break;
				case ("14"):
					JMenuItem opt14 = new JMenuItem(InterfazVista.MODIFICARCITA);
					opt14.addActionListener(new ControlMenu());
					procesos.add(opt14);
					break;
				}
				
			}
			JMenuItem opt15 = new JMenuItem(InterfazVista.VALORACION);
			opt15.addActionListener(new ControlMenu());
			procesos.add(opt15);

			VentanaPP.menuBarra.add(archivo);
			VentanaPP.menuBarra.add(procesos);
			VentanaPP.menuBarra.add(ayuda);

			VentanaPP.ventana.setJMenuBar(VentanaPP.menuBarra);

			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelLogin());
			VentanaPP.ventana.pack();
		} catch (ExceptionC1 exp) {
			JOptionPane.showMessageDialog(null, "Los campos est�n vacios", "ExceptionC1", JOptionPane.ERROR_MESSAGE);
		}catch (InstanceException exp) {
			JOptionPane.showMessageDialog(null, "El usuario ingresado no es un "+ControlOption.instancia, "ERROR", JOptionPane.ERROR_MESSAGE);
			
		} catch (ErrorAplication exp) {
			JOptionPane.showMessageDialog(null, "Usuario o contrase�a incorrectos", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public Boolean Instancia(User u) throws InstanceException {
		if (u instanceof AdminUser && ControlOption.instancia.equals(InterfazVista.INICIARADMIN) ) {
			return true;
		}
		else if (!(u instanceof AdminUser) && ControlOption.instancia.equals(InterfazVista.INICIARUSER) ) {
			return true;
		}
		else {
			throw new InstanceException();
		}
	}
}
