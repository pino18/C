package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import View.PanelLogin;
import View.PanelUsuario;
import View.VentanaPP;
import gestorAplicacion.users.User;

public class ControlModUsuario implements ActionListener {
	
// Guarda todos los campos que son modificados por el usuario en el PanelUsuario
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		ArrayList<String> values = PanelUsuario.Field.getValues();
		
		if (!values.contains("")) {
			User u = User.currentUser;
			u.setFullname(values.get(2));
			u.setEdad(values.get(3));
			u.setTelefono(values.get(4));
			u.setSexo(values.get(5));
			u.setEmail(values.get(7));
			u.setPassword(values.get(8));
			JOptionPane.showMessageDialog(null, "Guardado exitosamente", "informacion", JOptionPane.INFORMATION_MESSAGE);
			
			VentanaPP.contenedor.removeAll();
			VentanaPP.contenedor.add(new PanelLogin());
			VentanaPP.ventana.pack();
		}
		else {
			JOptionPane.showMessageDialog(null, "Por favor llene todos los campos", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

}
