package errorAplication;

public class NotFoundException extends ErrorAplication {

}
