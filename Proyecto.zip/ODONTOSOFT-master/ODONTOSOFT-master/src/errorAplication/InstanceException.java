package errorAplication;

public class InstanceException extends ErrorAplication {
	public InstanceException(){
		
	}
}
