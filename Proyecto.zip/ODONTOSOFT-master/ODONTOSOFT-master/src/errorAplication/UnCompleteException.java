package errorAplication;

public class UnCompleteException extends ErrorAplication {

}
