package errorAplication;

public class RandException extends ErrorAplication {

}
