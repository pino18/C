package errorAplication;

public class ErrorAplication extends Exception{
	
}
