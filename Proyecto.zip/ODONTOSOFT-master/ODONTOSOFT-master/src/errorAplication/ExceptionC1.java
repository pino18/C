package errorAplication;

public class ExceptionC1 extends ErrorAplication{
	public ExceptionC1(){
		
	}
}
