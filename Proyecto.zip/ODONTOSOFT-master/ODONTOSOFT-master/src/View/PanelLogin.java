package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelLogin extends JPanel{
	//Componentes de la ventana                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
	JLabel L1 = new JLabel();
	JLabel L2 = new JLabel();
	JLabel L3 = new JLabel();
	JLabel L4 = new JLabel();
	public ImageIcon imagen = new ImageIcon("logo.png");
	String Usuario;
	public PanelLogin(){
		JPanel PanelP = new JPanel();
		JPanel P1 = new JPanel();
		JPanel P2 = new JPanel();
		JPanel P3 = new JPanel();
		JPanel P4 = new JPanel();
		P1.setBackground(Color.lightGray);
		P2.setBackground(Color.lightGray);
		P3.setBackground(Color.lightGray);
		P4.setBackground(Color.lightGray);
		PanelP.setBackground(Color.lightGray);
		L3 = new JLabel();
		L3.setBounds(10,80,400,400);
		L4 = new JLabel("ODONTOSOFT");
		P4.add(L4);
		L4.setFont(new Font("Agency FB",Font.BOLD,70));
		L4.setForeground(Color.WHITE);
		L3.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(400, 350, Image.SCALE_SMOOTH)));
		P2.add(L3);
		P1.setLayout(new BorderLayout(10,10));
		L1 = new JLabel("Bienvenido");
		L1.setFont(new Font("arial",Font.PLAIN,20));
		P3.add(L1);
		P1.add(P3,BorderLayout.NORTH);
		P1.add(L3,BorderLayout.CENTER);
		P1.add(P4,BorderLayout.SOUTH);
		PanelP.add(P1);
		this.add(PanelP);
		setBackground(Color.lightGray);		
	}

}