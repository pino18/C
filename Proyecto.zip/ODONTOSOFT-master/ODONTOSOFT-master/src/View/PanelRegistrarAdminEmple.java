package View;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Control.ControlMenu;
import Control.ControlOption;
import Control.ControlRegistrar;
import Control.ControlRegistrarAdmin;
import Control.ControlRegistrarOpt;
import View.FieldPanel.FieldPanel;

public class PanelRegistrarAdminEmple extends JPanel{
	public static String kind;
	JComboBox<String> option;
	public static JPanel PP;
	public static FieldPanel Field;
	JButton registrar;
	JButton volver;
	
	public static final String ADMIN = "Admin";
	public static final String EMPLEADO = "Empleado";
	
	public PanelRegistrarAdminEmple(String kind, FieldPanel FP) {
		this.kind=kind;
		Field=FP;
		PP = new JPanel();
		PP.setLayout(new BorderLayout(10,10));
		
		JLabel title = new JLabel("Registrar nuevo usuario "+kind);
		
		JPanel buttons = new JPanel();
		registrar = new JButton(InterfazVista.REGISTRAR2);
		registrar.addActionListener(new ControlRegistrarAdmin());
		volver = new JButton(InterfazVista.VOLVER);
		volver.setActionCommand(InterfazVista.CANCELAR);
		volver.addActionListener(new ControlMenu());
		buttons.add(registrar);
		buttons.add(volver);
		
		PP.add(title, BorderLayout.NORTH);
		PP.add(Field, BorderLayout.CENTER);
		PP.add(buttons, BorderLayout.SOUTH);
		this.add(PP);
	}
}
