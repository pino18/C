package View;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Control.ControlMenu;
import Control.ControlModUsuario;
import View.FieldPanel.FieldPanel;

public class PanelUsuario extends JPanel {
	
	public static JPanel PP;
	public static FieldPanel Field;
	JButton modificar;
	JButton volver;

//Constructor que crea el controlador y permite crear el Field que se manda desde el controlador
// con los valores del mismo
	
	public PanelUsuario(Boolean modi, FieldPanel FP) {

		Field=FP;
		PP = new JPanel();
		PP.setLayout(new BorderLayout(10,10));
		
		JLabel title = new JLabel("Informaci�n del usuario");
		
		modificar = new JButton(InterfazVista.MODIFICAR);
		volver = new JButton(InterfazVista.VOLVER);
		JPanel buttons = new JPanel();
		
//modi Cambia los botones para el Field 
		if (modi) {
			modificar.setActionCommand(InterfazVista.MODIFICARUSER);
			modificar.addActionListener(new ControlMenu());

			volver.setActionCommand(InterfazVista.CANCELAR);
			volver.addActionListener(new ControlMenu());
		}
		else {
			modificar.setLabel(InterfazVista.GUARDAR);
			modificar.setActionCommand(InterfazVista.GUARDAR);
			modificar.addActionListener(new ControlModUsuario());
			
			volver.setLabel(InterfazVista.CANCELAR);
			volver.setActionCommand(InterfazVista.CANCELAR);
			volver.addActionListener(new ControlMenu());
		}
		
		
		buttons.add(modificar);
		buttons.add(volver);
		
		PP.add(title, BorderLayout.NORTH);
		PP.add(Field, BorderLayout.CENTER);
		PP.add(buttons, BorderLayout.SOUTH);
		this.add(PP);
	}
}
