package View;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

import Control.ControlMenu;
import Control.ControlModificarHistoria;
import Control.ControlSeeOpt;
import View.FieldPanel.FieldPanel;

public class PanelModificarHistoria extends JPanel {
	JButton guardar;
	JButton volver;
	public static JTextField ID = new JTextField("",15);
	public static FieldPanel Field;


	public PanelModificarHistoria(Boolean Modi, FieldPanel FP) {
		Field = FP;

		JPanel PP = new JPanel();
		PP.setLayout(new BorderLayout(7, 7));

		JPanel P1 = new JPanel();
		P1.setLayout(new GridLayout(3, 1, 5, 5));
		JLabel title = new JLabel("Modificar la historia cl�nica");
		String[] description1 = { "Permite cambiar la informacion a tener en cuenta del paciente ",
				"Ingrese la identificaci�n del usuario: " };
		P1.add(title);
		P1.add(new JLabel(description1[0]));
		if (Modi) {
			JPanel PSub = new JPanel();
			PSub.add(new JLabel(description1[1]));
			PSub.add(ID);
			P1.add(PSub);
			guardar = new JButton(InterfazVista.ACEPTAR);
			guardar.addActionListener(new ControlModificarHistoria());
			
		}
		else {
			guardar = new JButton(InterfazVista.GUARDAR);
			guardar.addActionListener(new ControlModificarHistoria());
			PP.add(Field, BorderLayout.CENTER);
		}

		JPanel P3 = new JPanel();
		P3.add(guardar);
		volver = new JButton(InterfazVista.VOLVER);
		volver.setActionCommand(InterfazVista.CANCELAR);
		volver.addActionListener(new ControlMenu());
		P3.add(volver);

		PP.add(P1, BorderLayout.NORTH);
		
		PP.add(P3, BorderLayout.SOUTH);
		this.add(PP);
	}
}
