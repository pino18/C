package View;

import javax.swing.JPanel;

public class PanelVoid extends JPanel{
	public PanelVoid() {
		
	}
}
