package uiMain.operations;

import uiMain.Main;
import uiMain.OpcionDeMenu;
import java.util.Scanner;
import BaseDatos.Data;
import gestorAplicacion.documents.Cita;
import gestorAplicacion.users.Empleado;
import gestorAplicacion.users.Paciente;
import gestorAplicacion.users.User;
import uiMain.OpcionDeMenu;

public class Renunciar extends OpcionDeMenu {//Hace la solicit�d de renuncia de un empleado registrado
	public Renunciar(String key) {
		super(key);
	}

	@Override
	public void ejecutar() {// Hace la validaci�n de usuario para poder confirmar que el usuario es el empleado que quiere renunciar, luego envia un mensaje de confirmaci�n para asegurarse que el empleado si quiere renunciar
		Empleado E = (Empleado) Main.user;
		Scanner leer = new Scanner(System.in);
		while (true) {
			System.out.print("Ingrese el nombre de usuario nuevamente: ");
			String username = leer.next();
			System.out.print("Ingrese su contrase�a nuevamente: ");
			String Password = leer.next();
			if (username.contentEquals(E.getUsername())&&Password.equals(E.getPassword())) {
				System.out.println("Validacion exitosa ");
				System.out.println("�Seguro que desea continuar? (Si: 1, No: 2) :");
				int OP = leer.nextInt();
				if (OP == 1) {
					Data.users.remove(username);
					System.out.println("Renucia exitosa");
				}else if(OP==2){
					System.out.println("Renucia cancelada");
				}
				break;
			} else {
				System.out.println("Validacion fallida, por favor ingrese los datos nuevamente:  ");
			}
		}

	}

	@Override
	public String toString() {
		return "Renuncia";
	}

}
