# EntregaMenu
El siguiente es un ejemplo basico aproximado de la entrega practica 1 de oop, este sera actualizado en los proximos días.
usuario administrador
nombre usuario: admin
contraseña: 12345
